import React, { useState, useEffect, useMemo } from 'react';
import LandingPage from './components/LandingPage';
import { DashboardHeader } from './components/DashboardHeader';
import { FilterControls } from './components/FilterControls';
import { ArbitrageTable } from './components/ArbitrageTable';
import { getMockContracts } from './services/mockData';
import { TimeDecayArbEngine } from './utils/arbitrageEngine';
import type { ArbitrageOpportunity, FilterOptions, SortField, SortDirection } from './types/market';

function App() {
  const [showDashboard, setShowDashboard] = useState(false);
  const [opportunities, setOpportunities] = useState<ArbitrageOpportunity[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [sortField, setSortField] = useState<SortField>('arbSpread');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [filters, setFilters] = useState<FilterOptions>({
    minArbSpread: 3,
    maxTimeRemaining: 365,
    categories: [],
    riskLevels: [],
    confidenceLevels: []
  });

  // Load and refresh data
  const refreshData = async () => {
    setIsLoading(true);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const contracts = getMockContracts();
      const arbOpportunities = TimeDecayArbEngine.findArbitrageOpportunities(
        contracts,
        0.5, // Base probability
        0    // Include all opportunities for filtering
      );
      
      setOpportunities(arbOpportunities);
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Initial data load when dashboard is shown
  useEffect(() => {
    if (showDashboard) {
      refreshData();
      
      // Set up auto-refresh every 30 seconds
      const interval = setInterval(refreshData, 30000);
      return () => clearInterval(interval);
    }
  }, [showDashboard]);

  // Apply filters and sorting
  const filteredOpportunities = useMemo(() => {
    let filtered = opportunities.filter(opp => {
      // Arbitrage spread filter
      if (opp.arbSpread < filters.minArbSpread) return false;
      
      // Time remaining filter
      if (opp.timeRemaining > filters.maxTimeRemaining) return false;
      
      // Category filter
      if (filters.categories.length > 0 && !filters.categories.includes(opp.contract.category)) {
        return false;
      }
      
      // Risk level filter
      if (filters.riskLevels.length > 0 && !filters.riskLevels.includes(opp.risk)) {
        return false;
      }
      
      // Confidence level filter
      if (filters.confidenceLevels.length > 0 && !filters.confidenceLevels.includes(opp.confidence)) {
        return false;
      }
      
      return true;
    });

    // Apply sorting
    filtered.sort((a, b) => {
      let aValue: number;
      let bValue: number;
      
      switch (sortField) {
        case 'arbSpread':
          aValue = a.arbSpread;
          bValue = b.arbSpread;
          break;
        case 'timeRemaining':
          aValue = a.timeRemaining;
          bValue = b.timeRemaining;
          break;
        case 'volume24h':
          aValue = a.contract.volume24h;
          bValue = b.contract.volume24h;
          break;
        case 'profitPotential':
          aValue = a.profitPotential;
          bValue = b.profitPotential;
          break;
        default:
          return 0;
      }
      
      if (sortDirection === 'desc') {
        return bValue - aValue;
      }
      return aValue - bValue;
    });

    return filtered;
  }, [opportunities, filters, sortField, sortDirection]);

  // Calculate summary statistics
  const stats = useMemo(() => {
    const totalOpportunities = filteredOpportunities.length;
    const avgProfitPotential = filteredOpportunities.length > 0
      ? filteredOpportunities.reduce((sum, opp) => sum + opp.profitPotential, 0) / filteredOpportunities.length
      : 0;

    return {
      totalOpportunities,
      avgProfitPotential
    };
  }, [filteredOpportunities]);

  const handleSort = (field: SortField, direction: SortDirection) => {
    setSortField(field);
    setSortDirection(direction);
  };

  const handleGetStarted = () => {
    setShowDashboard(true);
  };

  const handleBackToLanding = () => {
    setShowDashboard(false);
  };

  // Show landing page by default
  if (!showDashboard) {
    return <LandingPage onGetStarted={handleGetStarted} />;
  }

  // Show dashboard
  return (
    <div className="min-h-screen bg-navy-900">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Back to Overview button */}
        <div className="mb-4">
          <button
            onClick={handleBackToLanding}
            className="flex items-center text-warm-400 hover:text-gold-300 transition-colors text-sm"
          >
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Overview
          </button>
        </div>

        <DashboardHeader
          totalOpportunities={stats.totalOpportunities}
          totalPotentialProfit={stats.avgProfitPotential}
          onRefresh={refreshData}
          isLoading={isLoading}
          lastUpdated={lastUpdated}
        />

        <FilterControls
          filters={filters}
          onFiltersChange={setFilters}
          totalContracts={opportunities.length}
          filteredCount={filteredOpportunities.length}
        />

        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-warm-100">
              Arbitrage Opportunities
            </h2>
            
            <div className="flex items-center space-x-4 text-sm text-warm-400">
              <div className="flex items-center">
                <div className="w-2 h-2 bg-emerald-400 rounded-full mr-2"></div>
                Undervalued "No" positions
              </div>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-gold-400 rounded-full mr-2"></div>
                Time decay advantage
              </div>
            </div>
          </div>
          
          <ArbitrageTable
            opportunities={filteredOpportunities}
            onSort={handleSort}
            sortField={sortField}
            sortDirection={sortDirection}
          />
        </div>

        {/* Footer with methodology explanation */}
        <div className="bg-warm-800 border border-warm-600 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gold-300 mb-3">Template Methodology</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
            <div>
              <h4 className="font-medium text-gold-400 mb-2">1. Time Decay Analysis</h4>
              <p className="text-warm-200">
                Mathematical model calculates theoretical "No" prices based on time decay curves. 
                Easily customizable for different probability distributions.
              </p>
            </div>
            <div>
              <h4 className="font-medium text-gold-400 mb-2">2. Arbitrage Detection</h4>
              <p className="text-warm-200">
                Compares market prices against theoretical values to identify opportunities. 
                Modular design allows integration with any prediction market API.
              </p>
            </div>
            <div>
              <h4 className="font-medium text-gold-400 mb-2">3. Risk Assessment</h4>
              <p className="text-warm-200">
                Automated confidence scoring based on configurable parameters like spread size, 
                volume, and time remaining. Fully customizable scoring logic.
              </p>
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-warm-700 text-xs text-warm-500">
            <p>
              <strong>Template Notice:</strong> This is a demonstration template with mock data. 
              Integrate with real market APIs and customize the mathematical models for production use.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;