import type { MarketContract, ArbitrageOpportunity } from '../types/market';

export class TimeDecayArbEngine {
  /**
   * Calculates theoretical "No" price based on time decay
   * @param startDate Contract start date
   * @param endDate Contract end date  
   * @param baseProbability Initial probability of "Yes" outcome (0-1)
   * @returns Theoretical "No" price (0-1)
   */
  static calculateTheoreticalNoPrice(
    startDate: string, 
    endDate: string, 
    baseProbability: number = 0.5
  ): number {
    const start = new Date(startDate).getTime();
    const end = new Date(endDate).getTime();
    const now = new Date().getTime();
    
    const totalDuration = end - start;
    const elapsed = now - start;
    
    // Prevent division by zero and handle edge cases
    if (totalDuration <= 0 || elapsed < 0) return 1 - baseProbability;
    if (elapsed >= totalDuration) return 1.0; // Event should have concluded
    
    const timeElapsed = Math.min(elapsed / totalDuration, 1);
    
    // Time decay formula: As time passes without event, "No" becomes more likely
    // Uses exponential decay curve for more realistic probability modeling
    const decayFactor = Math.pow(1 - timeElapsed, 0.7);
    const theoreticalNoPrice = 1 - (baseProbability * decayFactor);
    
    return Math.max(0, Math.min(1, theoreticalNoPrice));
  }
  
  /**
   * Calculates time elapsed ratio (0-1)
   */
  static calculateTimeElapsed(startDate: string, endDate: string): number {
    const start = new Date(startDate).getTime();
    const end = new Date(endDate).getTime();
    const now = new Date().getTime();
    
    const totalDuration = end - start;
    const elapsed = now - start;
    
    if (totalDuration <= 0) return 1;
    return Math.max(0, Math.min(1, elapsed / totalDuration));
  }
  
  /**
   * Calculates remaining time in days
   */
  static calculateTimeRemaining(endDate: string): number {
    const end = new Date(endDate).getTime();
    const now = new Date().getTime();
    
    const remaining = end - now;
    return Math.max(0, remaining / (1000 * 60 * 60 * 24));
  }
  
  /**
   * Determines confidence level based on multiple factors
   */
  static calculateConfidence(
    arbSpread: number,
    timeRemaining: number,
    volume24h: number
  ): 'HIGH' | 'MEDIUM' | 'LOW' {
    let score = 0;
    
    // Higher spread = higher confidence
    if (arbSpread > 15) score += 3;
    else if (arbSpread > 8) score += 2;
    else if (arbSpread > 3) score += 1;
    
    // More time remaining = lower confidence (more uncertainty)
    if (timeRemaining < 1) score += 2;
    else if (timeRemaining < 7) score += 1;
    
    // Higher volume = higher confidence (more liquid market)
    if (volume24h > 10000) score += 2;
    else if (volume24h > 1000) score += 1;
    
    if (score >= 6) return 'HIGH';
    if (score >= 3) return 'MEDIUM';
    return 'LOW';
  }
  
  /**
   * Calculates risk level based on market characteristics
   */
  static calculateRisk(
    timeRemaining: number,
    volume24h: number,
    arbSpread: number
  ): 'LOW' | 'MEDIUM' | 'HIGH' {
    let riskScore = 0;
    
    // More time = higher risk (more can change)
    if (timeRemaining > 30) riskScore += 3;
    else if (timeRemaining > 7) riskScore += 2;
    else if (timeRemaining > 1) riskScore += 1;
    
    // Lower volume = higher risk (less liquidity)
    if (volume24h < 100) riskScore += 3;
    else if (volume24h < 1000) riskScore += 2;
    else if (volume24h < 5000) riskScore += 1;
    
    // Very high spreads might indicate hidden information
    if (arbSpread > 25) riskScore += 2;
    
    if (riskScore >= 6) return 'HIGH';
    if (riskScore >= 3) return 'MEDIUM';
    return 'LOW';
  }
  
  /**
   * Main function to identify arbitrage opportunities
   */
  static findArbitrageOpportunities(
    contracts: MarketContract[],
    baseProbability: number = 0.5,
    minSpread: number = 3
  ): ArbitrageOpportunity[] {
    const opportunities: ArbitrageOpportunity[] = [];
    
    for (const contract of contracts) {
      const theoreticalNoPrice = this.calculateTheoreticalNoPrice(
        contract.startDate,
        contract.endDate,
        baseProbability
      );
      
      const actualNoPrice = contract.currentNoPrice;
      const arbSpread = ((theoreticalNoPrice - actualNoPrice) / actualNoPrice) * 100;
      
      // Only include if spread exceeds minimum threshold
      if (arbSpread >= minSpread) {
        const timeElapsed = this.calculateTimeElapsed(contract.startDate, contract.endDate);
        const timeRemaining = this.calculateTimeRemaining(contract.endDate);
        const confidence = this.calculateConfidence(arbSpread, timeRemaining, contract.volume24h);
        const risk = this.calculateRisk(timeRemaining, contract.volume24h, arbSpread);
        
        opportunities.push({
          contract,
          theoreticalNoPrice,
          actualNoPrice,
          arbSpread,
          timeElapsed,
          timeRemaining,
          confidence,
          profitPotential: arbSpread * 0.8, // Conservative estimate accounting for fees
          risk
        });
      }
    }
    
    // Sort by arbitrage spread (highest first)
    return opportunities.sort((a, b) => b.arbSpread - a.arbSpread);
  }
}

export default TimeDecayArbEngine;