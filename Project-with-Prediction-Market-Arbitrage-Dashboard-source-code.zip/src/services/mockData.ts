import type { MarketContract } from '../types/market';

// Mock data simulating Polymarket contracts
export const mockContracts: MarketContract[] = [
  {
    id: '1',
    question: 'Will Bitcoin hit $100k by December 31st, 2024?',
    description: 'This market resolves to "Yes" if Bitcoin (BTC) reaches or exceeds $100,000 USD on any major exchange before 11:59 PM ET on December 31st, 2024.',
    startDate: '2024-01-01T00:00:00Z',
    endDate: '2024-12-31T23:59:59Z',
    currentNoPrice: 0.35,
    currentYesPrice: 0.65,
    volume24h: 45000,
    totalVolume: 1200000,
    category: 'Crypto',
    tags: ['Bitcoin', 'Price', 'Cryptocurrency'],
    url: 'https://polymarket.com/event/bitcoin-100k-2024'
  },
  {
    id: '2',
    question: 'Will there be a US recession by Q2 2024?',
    description: 'Resolves "Yes" if the National Bureau of Economic Research officially declares that the US entered a recession at any point during Q1 or Q2 2024.',
    startDate: '2024-01-01T00:00:00Z',
    endDate: '2024-06-30T23:59:59Z',
    currentNoPrice: 0.82,
    currentYesPrice: 0.18,
    volume24h: 12500,
    totalVolume: 890000,
    category: 'Economics',
    tags: ['Recession', 'US Economy', 'NBER'],
    url: 'https://polymarket.com/event/us-recession-q2-2024'
  },
  {
    id: '3',
    question: 'Will OpenAI release GPT-5 by end of 2024?',
    description: 'Market resolves "Yes" if OpenAI officially announces and releases GPT-5 or a model explicitly described as the successor to GPT-4 by December 31, 2024.',
    startDate: '2024-03-01T00:00:00Z',
    endDate: '2024-12-31T23:59:59Z',
    currentNoPrice: 0.45,
    currentYesPrice: 0.55,
    volume24h: 67800,
    totalVolume: 750000,
    category: 'Technology',
    tags: ['AI', 'OpenAI', 'GPT', 'Release'],
    url: 'https://polymarket.com/event/openai-gpt5-2024'
  },
  {
    id: '4',
    question: 'Will Trump win the 2024 Presidential Election?',
    description: 'Resolves "Yes" if Donald Trump wins the 2024 US Presidential Election and is sworn in as President in January 2025.',
    startDate: '2023-11-01T00:00:00Z',
    endDate: '2024-11-05T23:59:59Z',
    currentNoPrice: 0.52,
    currentYesPrice: 0.48,
    volume24h: 234000,
    totalVolume: 15600000,
    category: 'Politics',
    tags: ['Election', 'Trump', '2024', 'President'],
    url: 'https://polymarket.com/event/trump-2024-election'
  },
  {
    id: '5',
    question: 'Will Ethereum switch to a new consensus mechanism by 2025?',
    description: 'Resolves "Yes" if Ethereum implements a consensus mechanism other than Proof of Stake before January 1st, 2025.',
    startDate: '2024-01-15T00:00:00Z',
    endDate: '2024-12-31T23:59:59Z',
    currentNoPrice: 0.91,
    currentYesPrice: 0.09,
    volume24h: 8900,
    totalVolume: 340000,
    category: 'Crypto',
    tags: ['Ethereum', 'Consensus', 'Blockchain'],
    url: 'https://polymarket.com/event/ethereum-consensus-2025'
  },
  {
    id: '6',
    question: 'Will SpaceX successfully land humans on Mars by 2026?',
    description: 'Market resolves "Yes" if SpaceX successfully lands human astronauts on Mars and they survive for at least 24 hours on the surface by December 31, 2026.',
    startDate: '2024-02-01T00:00:00Z',
    endDate: '2026-12-31T23:59:59Z',
    currentNoPrice: 0.15,
    currentYesPrice: 0.85,
    volume24h: 156000,
    totalVolume: 2800000,
    category: 'Space',
    tags: ['SpaceX', 'Mars', 'Space Exploration'],
    url: 'https://polymarket.com/event/spacex-mars-landing-2026'
  },
  {
    id: '7',
    question: 'Will Apple announce a VR headset under $1000 in 2024?',
    description: 'Resolves "Yes" if Apple officially announces a VR/AR headset with a retail price under $1000 USD during 2024.',
    startDate: '2024-01-01T00:00:00Z',
    endDate: '2024-12-31T23:59:59Z',
    currentNoPrice: 0.73,
    currentYesPrice: 0.27,
    volume24h: 23400,
    totalVolume: 567000,
    category: 'Technology',
    tags: ['Apple', 'VR', 'Headset', 'Announcement'],
    url: 'https://polymarket.com/event/apple-vr-under-1000-2024'
  },
  {
    id: '8',
    question: 'Will there be a major social media platform launch in 2024?',
    description: 'Resolves "Yes" if a new social media platform gains over 50 million active users within 6 months of launch during 2024.',
    startDate: '2024-01-01T00:00:00Z',
    endDate: '2024-12-31T23:59:59Z',
    currentNoPrice: 0.68,
    currentYesPrice: 0.32,
    volume24h: 34500,
    totalVolume: 445000,
    category: 'Technology',
    tags: ['Social Media', 'Launch', 'Platform'],
    url: 'https://polymarket.com/event/new-social-platform-2024'
  }
];

// Function to simulate real-time price updates
export function getUpdatedContract(contract: MarketContract): MarketContract {
  const volatility = 0.02; // 2% max price movement
  const priceChange = (Math.random() - 0.5) * volatility;
  
  const newNoPrice = Math.max(0.01, Math.min(0.99, contract.currentNoPrice + priceChange));
  const newYesPrice = 1 - newNoPrice;
  
  return {
    ...contract,
    currentNoPrice: newNoPrice,
    currentYesPrice: newYesPrice,
    volume24h: contract.volume24h + Math.floor(Math.random() * 1000)
  };
}

export function getMockContracts(): MarketContract[] {
  return mockContracts.map(getUpdatedContract);
}