import React, { useState } from 'react';
import type { ArbitrageOpportunity, SortField, SortDirection } from '../types/market';

interface ArbitrageTableProps {
  opportunities: ArbitrageOpportunity[];
  onSort: (field: SortField, direction: SortDirection) => void;
  sortField: SortField;
  sortDirection: SortDirection;
}

export function ArbitrageTable({ 
  opportunities, 
  onSort, 
  sortField, 
  sortDirection 
}: ArbitrageTableProps) {
  const handleSort = (field: SortField) => {
    const newDirection: SortDirection = 
      sortField === field && sortDirection === 'desc' ? 'asc' : 'desc';
    onSort(field, newDirection);
  };

  const formatPercent = (value: number) => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  const formatDays = (days: number) => {
    if (days < 1) {
      return `${(days * 24).toFixed(1)}h`;
    }
    return `${days.toFixed(1)}d`;
  };

  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case 'HIGH': return 'text-green-400';
      case 'MEDIUM': return 'text-yellow-400';
      case 'LOW': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'LOW': return 'text-green-400';
      case 'MEDIUM': return 'text-yellow-400';
      case 'HIGH': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) {
      return <span className="text-gray-500 ml-1">↕</span>;
    }
    return (
      <span className="text-blue-400 ml-1">
        {sortDirection === 'desc' ? '↓' : '↑'}
      </span>
    );
  };

  return (
    <div className="bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-slate-900">
            <tr className="border-b border-slate-700">
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300">
                Market
              </th>
              <th 
                className="px-6 py-4 text-left text-sm font-semibold text-gray-300 cursor-pointer hover:text-white"
                onClick={() => handleSort('arbSpread')}
              >
                Arb Spread <SortIcon field="arbSpread" />
              </th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300">
                Current/Theoretical
              </th>
              <th 
                className="px-6 py-4 text-left text-sm font-semibold text-gray-300 cursor-pointer hover:text-white"
                onClick={() => handleSort('timeRemaining')}
              >
                Time Left <SortIcon field="timeRemaining" />
              </th>
              <th 
                className="px-6 py-4 text-left text-sm font-semibold text-gray-300 cursor-pointer hover:text-white"
                onClick={() => handleSort('volume24h')}
              >
                24h Volume <SortIcon field="volume24h" />
              </th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300">
                Confidence/Risk
              </th>
              <th 
                className="px-6 py-4 text-left text-sm font-semibold text-gray-300 cursor-pointer hover:text-white"
                onClick={() => handleSort('profitPotential')}
              >
                Est. Profit <SortIcon field="profitPotential" />
              </th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300">
                Action
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700">
            {opportunities.map((opp, index) => (
              <tr key={opp.contract.id} className="hover:bg-slate-700/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="max-w-xs">
                    <p className="text-sm font-medium text-white truncate">
                      {opp.contract.question}
                    </p>
                    <p className="text-xs text-gray-400">
                      {opp.contract.category}
                    </p>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className={`text-lg font-bold ${
                      opp.arbSpread > 10 ? 'text-green-400' : 
                      opp.arbSpread > 5 ? 'text-yellow-400' : 'text-orange-400'
                    }`}>
                      {formatPercent(opp.arbSpread)}
                    </span>
                    <span className="text-xs text-gray-400">
                      Rank #{index + 1}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm">
                    <div className="text-white">
                      Current: ${(opp.actualNoPrice * 100).toFixed(1)}¢
                    </div>
                    <div className="text-green-400">
                      Theory: ${(opp.theoreticalNoPrice * 100).toFixed(1)}¢
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="text-white text-sm">
                      {formatDays(opp.timeRemaining)}
                    </span>
                    <div className="w-16 h-1.5 bg-gray-700 rounded-full mt-1">
                      <div 
                        className="h-full bg-blue-500 rounded-full"
                        style={{ width: `${opp.timeElapsed * 100}%` }}
                      />
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm">
                    <span className="text-white">
                      ${opp.contract.volume24h.toLocaleString()}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-col text-xs">
                    <span className={getConfidenceColor(opp.confidence)}>
                      {opp.confidence}
                    </span>
                    <span className={getRiskColor(opp.risk)}>
                      {opp.risk} Risk
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="text-green-400 font-semibold">
                    {formatPercent(opp.profitPotential)}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <a
                    href={opp.contract.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors"
                  >
                    Trade
                    <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {opportunities.length === 0 && (
        <div className="p-8 text-center">
          <p className="text-gray-400">No arbitrage opportunities found with current filters.</p>
          <p className="text-sm text-gray-500 mt-2">Try adjusting your minimum spread threshold.</p>
        </div>
      )}
    </div>
  );
}