import React from 'react';

interface LandingPageProps {
  onGetStarted?: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted }) => {
  const handleGetStarted = () => {
    if (onGetStarted) {
      onGetStarted();
    }
  };

  const handleViewDemo = () => {
    if (onGetStarted) {
      onGetStarted();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-navy-to-warm">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-navy-900 opacity-50"></div>
        <div className="relative container mx-auto px-6 py-24 text-center">
          <div className="animate-fadeIn">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="text-gradient-gold-bronze">Prediction Market</span>
              <br />
              <span className="text-warm-100">Arbitrage Engine</span>
            </h1>
            <p className="text-xl text-warm-300 mb-8 max-w-3xl mx-auto leading-relaxed">
              Discover profitable arbitrage opportunities across multiple prediction markets in real-time. 
              Advanced algorithms identify price discrepancies for maximum returns.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={handleGetStarted}
                className="bg-gradient-gold px-8 py-4 rounded-lg text-navy-900 font-semibold hover:shadow-gold-lg transition-all transform hover:scale-105"
              >
                Start Finding Opportunities
              </button>
              <button 
                onClick={handleViewDemo}
                className="border-2 border-gold-light text-gold-light px-8 py-4 rounded-lg font-semibold hover:bg-gold-light hover:text-navy-900 transition-all"
              >
                View Demo
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <section className="py-20 bg-navy-800">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gradient-gold mb-4">
              Why Choose Our Platform?
            </h2>
            <p className="text-warm-300 text-lg max-w-2xl mx-auto">
              Built for serious traders who want to maximize their prediction market profits
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-warm-800 p-8 rounded-xl hover:shadow-gold transition-all transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-gold rounded-lg mb-6 flex items-center justify-center">
                <svg className="w-8 h-8 text-navy-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gold-300 mb-4">Real-Time Detection</h3>
              <p className="text-warm-200">
                Our advanced algorithms scan multiple markets simultaneously, identifying arbitrage opportunities 
                within seconds of their emergence.
              </p>
            </div>

            <div className="bg-warm-800 p-8 rounded-xl hover:shadow-gold transition-all transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-gold rounded-lg mb-6 flex items-center justify-center">
                <svg className="w-8 h-8 text-navy-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gold-300 mb-4">Smart Analytics</h3>
              <p className="text-warm-200">
                Comprehensive analysis of profit margins, execution time, and risk factors 
                to help you make informed decisions.
              </p>
            </div>

            <div className="bg-warm-800 p-8 rounded-xl hover:shadow-gold transition-all transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-gold rounded-lg mb-6 flex items-center justify-center">
                <svg className="w-8 h-8 text-navy-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gold-300 mb-4">Secure Trading</h3>
              <p className="text-warm-200">
                Enterprise-grade security measures and risk management protocols 
                to protect your capital and maximize returns.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-navy-900">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl md:text-4xl font-bold text-gradient-gold mb-2">$2.4M+</div>
              <p className="text-warm-300">Total Profits Generated</p>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-bold text-gradient-gold mb-2">15,000+</div>
              <p className="text-warm-300">Opportunities Found</p>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-bold text-gradient-gold mb-2">98.2%</div>
              <p className="text-warm-300">Success Rate</p>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-bold text-gradient-gold mb-2">{`<`}2s</div>
              <p className="text-warm-300">Average Detection Time</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-warm-800">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gradient-gold mb-4">
              How It Works
            </h2>
            <p className="text-warm-200 text-lg max-w-2xl mx-auto">
              Simple, automated process to maximize your prediction market returns
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-gold rounded-full mx-auto mb-6 flex items-center justify-center">
                <span className="text-2xl font-bold text-navy-900">1</span>
              </div>
              <h3 className="text-xl font-semibold text-gold-300 mb-4">Scan Markets</h3>
              <p className="text-warm-200">
                Our system continuously monitors prediction markets across multiple platforms, 
                analyzing thousands of events and odds.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-gold rounded-full mx-auto mb-6 flex items-center justify-center">
                <span className="text-2xl font-bold text-navy-900">2</span>
              </div>
              <h3 className="text-xl font-semibold text-gold-300 mb-4">Identify Opportunities</h3>
              <p className="text-warm-200">
                Advanced algorithms detect price discrepancies and calculate profit potential, 
                factoring in fees and execution time.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-gold rounded-full mx-auto mb-6 flex items-center justify-center">
                <span className="text-2xl font-bold text-navy-900">3</span>
              </div>
              <h3 className="text-xl font-semibold text-gold-300 mb-4">Execute Trades</h3>
              <p className="text-warm-200">
                Get instant notifications with detailed execution plans, 
                or use our automated trading features for hands-off profits.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-navy-900">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gradient-gold mb-4">
              Choose Your Plan
            </h2>
            <p className="text-warm-300 text-lg max-w-2xl mx-auto">
              Flexible pricing options to suit traders of all levels
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="bg-warm-800 p-8 rounded-xl border border-warm-600">
              <h3 className="text-xl font-semibold text-gold-300 mb-4">Starter</h3>
              <div className="text-3xl font-bold text-gradient-gold mb-6">$99<span className="text-lg text-warm-300">/month</span></div>
              <ul className="space-y-3 text-warm-200 mb-8">
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Real-time opportunity alerts
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Up to 100 opportunities/day
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Basic analytics dashboard
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Email support
                </li>
              </ul>
              <button 
                onClick={handleGetStarted}
                className="w-full bg-gradient-gold text-navy-900 py-3 rounded-lg font-semibold hover:shadow-gold-lg transition-all"
              >
                Get Started
              </button>
            </div>

            <div className="bg-warm-800 p-8 rounded-xl border-2 border-gold-500 relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-gradient-gold text-navy-900 px-4 py-2 rounded-full text-sm font-semibold">
                  Most Popular
                </span>
              </div>
              <h3 className="text-xl font-semibold text-gold-300 mb-4">Professional</h3>
              <div className="text-3xl font-bold text-gradient-gold mb-6">$299<span className="text-lg text-warm-300">/month</span></div>
              <ul className="space-y-3 text-warm-200 mb-8">
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Unlimited opportunities
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Advanced filtering & sorting
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  API access for automation
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Priority support & training
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Historical data & backtesting
                </li>
              </ul>
              <button 
                onClick={handleGetStarted}
                className="w-full bg-gradient-gold text-navy-900 py-3 rounded-lg font-semibold hover:shadow-gold-lg transition-all"
              >
                Upgrade Now
              </button>
            </div>

            <div className="bg-warm-800 p-8 rounded-xl border border-warm-600">
              <h3 className="text-xl font-semibold text-gold-300 mb-4">Enterprise</h3>
              <div className="text-3xl font-bold text-gradient-gold mb-6">Custom</div>
              <ul className="space-y-3 text-warm-200 mb-8">
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  White-label solutions
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Custom integrations
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Dedicated account manager
                </li>
                <li className="flex items-center">
                  <svg className="w-5 h-5 text-emerald-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  SLA guarantees
                </li>
              </ul>
              <button className="w-full border-2 border-gold-500 text-gold-300 py-3 rounded-lg font-semibold hover:bg-gold-500 hover:text-navy-900 transition-all">
                Contact Sales
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-navy-900 border-t border-warm-700 py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold text-gradient-gold mb-4">ArbitrageAI</h3>
              <p className="text-warm-300 text-sm">
                The leading prediction market arbitrage platform for serious traders.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-gold-300 mb-4">Product</h4>
              <ul className="space-y-2 text-warm-300 text-sm">
                <li><a href="#" className="hover:text-gold-300 transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-gold-300 transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-gold-300 transition-colors">API Documentation</a></li>
                <li><a href="#" className="hover:text-gold-300 transition-colors">Integrations</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-gold-300 mb-4">Support</h4>
              <ul className="space-y-2 text-warm-300 text-sm">
                <li><a href="#" className="hover:text-gold-300 transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-gold-300 transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-gold-300 transition-colors">Community</a></li>
                <li><a href="#" className="hover:text-gold-300 transition-colors">Status</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-gold-300 mb-4">Legal</h4>
              <ul className="space-y-2 text-warm-300 text-sm">
                <li><a href="#" className="hover:text-gold-300 transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-gold-300 transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-gold-300 transition-colors">Risk Disclosure</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-warm-700 mt-12 pt-8 text-center">
            <p className="text-warm-400 text-sm">
              © 2024 ArbitrageAI. All rights reserved. Well-documented &amp; commented.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;