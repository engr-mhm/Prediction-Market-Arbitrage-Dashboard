import React from 'react';
import type { FilterOptions } from '../types/market';

interface FilterControlsProps {
  filters: FilterOptions;
  onFiltersChange: (filters: FilterOptions) => void;
  totalContracts: number;
  filteredCount: number;
}

export function FilterControls({ 
  filters, 
  onFiltersChange, 
  totalContracts, 
  filteredCount 
}: FilterControlsProps) {
  const updateFilter = <K extends keyof FilterOptions>(
    key: K, 
    value: FilterOptions[K]
  ) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const toggleArrayItem = (
    array: string[], 
    item: string, 
    key: keyof Pick<FilterOptions, 'categories' | 'riskLevels' | 'confidenceLevels'>
  ) => {
    const newArray = array.includes(item)
      ? array.filter(i => i !== item)
      : [...array, item];
    updateFilter(key, newArray);
  };

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-lg p-6 mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Minimum Arbitrage Spread */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Min Arbitrage Spread
          </label>
          <div className="relative">
            <input
              type="range"
              min="0"
              max="25"
              step="0.5"
              value={filters.minArbSpread}
              onChange={(e) => updateFilter('minArbSpread', Number(e.target.value))}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
            />
            <div className="flex justify-between text-xs text-gray-400 mt-1">
              <span>0%</span>
              <span className="font-medium text-white">{filters.minArbSpread.toFixed(1)}%</span>
              <span>25%</span>
            </div>
          </div>
        </div>

        {/* Max Time Remaining */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Max Time Remaining
          </label>
          <div className="relative">
            <input
              type="range"
              min="1"
              max="365"
              step="1"
              value={filters.maxTimeRemaining}
              onChange={(e) => updateFilter('maxTimeRemaining', Number(e.target.value))}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
            />
            <div className="flex justify-between text-xs text-gray-400 mt-1">
              <span>1d</span>
              <span className="font-medium text-white">{filters.maxTimeRemaining}d</span>
              <span>365d</span>
            </div>
          </div>
        </div>

        {/* Categories */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Categories
          </label>
          <div className="space-y-2">
            {['Crypto', 'Politics', 'Technology', 'Economics', 'Space'].map(category => (
              <label key={category} className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.categories.includes(category)}
                  onChange={() => toggleArrayItem(filters.categories, category, 'categories')}
                  className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                />
                <span className="ml-2 text-sm text-gray-300">{category}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Risk & Confidence Levels */}
        <div>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Confidence Level
            </label>
            <div className="space-y-1">
              {['HIGH', 'MEDIUM', 'LOW'].map(level => (
                <label key={level} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.confidenceLevels.includes(level)}
                    onChange={() => toggleArrayItem(filters.confidenceLevels, level, 'confidenceLevels')}
                    className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                  />
                  <span className={`ml-2 text-sm ${
                    level === 'HIGH' ? 'text-green-400' : 
                    level === 'MEDIUM' ? 'text-yellow-400' : 'text-red-400'
                  }`}>
                    {level}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Risk Level
            </label>
            <div className="space-y-1">
              {['LOW', 'MEDIUM', 'HIGH'].map(level => (
                <label key={level} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.riskLevels.includes(level)}
                    onChange={() => toggleArrayItem(filters.riskLevels, level, 'riskLevels')}
                    className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                  />
                  <span className={`ml-2 text-sm ${
                    level === 'LOW' ? 'text-green-400' : 
                    level === 'MEDIUM' ? 'text-yellow-400' : 'text-red-400'
                  }`}>
                    {level}
                  </span>
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-700">
        <div className="text-sm text-gray-400">
          Showing <span className="font-medium text-white">{filteredCount}</span> of{' '}
          <span className="font-medium text-white">{totalContracts}</span> opportunities
        </div>
        
        <button
          onClick={() => onFiltersChange({
            minArbSpread: 3,
            maxTimeRemaining: 365,
            categories: [],
            riskLevels: [],
            confidenceLevels: []
          })}
          className="px-3 py-1 text-xs font-medium text-gray-400 hover:text-white transition-colors"
        >
          Reset Filters
        </button>
      </div>
    </div>
  );
}