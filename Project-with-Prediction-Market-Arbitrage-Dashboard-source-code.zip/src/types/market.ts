export interface MarketContract {
  id: string;
  question: string;
  description?: string;
  startDate: string;
  endDate: string;
  currentNoPrice: number;
  currentYesPrice: number;
  volume24h: number;
  totalVolume: number;
  category: string;
  tags: string[];
  url: string;
}

export interface ArbitrageOpportunity {
  contract: MarketContract;
  theoreticalNoPrice: number;
  actualNoPrice: number;
  arbSpread: number; // Percentage difference
  timeElapsed: number; // 0-1 ratio
  timeRemaining: number; // In days
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  profitPotential: number; // Expected profit percentage
  risk: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface EventState {
  name: string;
  description: string;
  probability: number;
  isComplete: boolean;
  completedAt?: string;
}

export interface StateTransition {
  from: string;
  to: string;
  probability: number;
  timeEstimate?: number; // Days
}

export interface MarkovChain {
  contractId: string;
  states: EventState[];
  transitions: StateTransition[];
  currentState: string;
}

export type SortField = 'arbSpread' | 'timeRemaining' | 'volume24h' | 'profitPotential';
export type SortDirection = 'asc' | 'desc';

export interface FilterOptions {
  minArbSpread: number;
  maxTimeRemaining: number;
  categories: string[];
  riskLevels: string[];
  confidenceLevels: string[];
}